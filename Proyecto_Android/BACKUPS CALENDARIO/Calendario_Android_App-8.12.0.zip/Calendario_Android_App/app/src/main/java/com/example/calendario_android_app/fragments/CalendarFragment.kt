package com.example.calendario_android_app.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.calendario_android_app.databinding.FragmentCalendarBinding
import com.example.calendario_android_app.adapters.CalendarAdapter
import com.example.calendario_android_app.adapters.EventAdapter
import com.example.calendario_android_app.viewmodel.EventViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@SuppressLint("NewApi") // Desugaring habilitado - soporta Android 7.0+
class CalendarFragment : Fragment() {

    private var _binding: FragmentCalendarBinding? = null
    private val binding get() = _binding!!
    
    private val eventViewModel: EventViewModel by viewModels()
    private lateinit var adaptadorEventos: EventAdapter
    private lateinit var adaptadorCalendario: CalendarAdapter
    
    private var mesAnioActual = YearMonth.now()
    private var fechaSeleccionada: LocalDate? = null
    private var idUsuario: Int = 1 // TODO: Obtener de sesión/login
    private var diasConEventos: List<Int> = emptyList()
    
    private val formateadorMes = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.forLanguageTag("es-ES"))
    private val formateadorEncabezado = DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.forLanguageTag("es-ES"))

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configurarCalendario()
        configurarEventos()
        configurarListeners()
        observarViewModel()
        
        eventViewModel.loadDiasConEventos(idUsuario, mesAnioActual.year, mesAnioActual.monthValue)
    }

    private fun configurarCalendario() {
        actualizarVisualizacionMes()
        
        val listaDias = generarDiasDelMes(mesAnioActual)
        
        adaptadorCalendario = CalendarAdapter(
            days = listaDias,
            currentMonth = mesAnioActual.monthValue,
            selectedDay = fechaSeleccionada?.dayOfMonth ?: -1,
            daysWithEvents = diasConEventos,
            onDayClick = { dia ->
                alSeleccionarDia(dia)
            }
        )
        
        binding.calendarRecyclerView.layoutManager = GridLayoutManager(context, 7)
        binding.calendarRecyclerView.adapter = adaptadorCalendario
    }

    private fun configurarEventos() {
        adaptadorEventos = EventAdapter(emptyList())
        binding.eventsRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.eventsRecyclerView.adapter = adaptadorEventos
        
        binding.tvScheduleHeader.visibility = View.GONE
    }

    private fun configurarListeners() {
        binding.fabCreateEvent.setOnClickListener {
            Toast.makeText(context, "Crear Evento Clicked", Toast.LENGTH_SHORT).show()
        }
        
        binding.btnToday.setOnClickListener {
            irAHoy()
        }
        
        binding.btnPrevMonth.setOnClickListener {
            cambiarMes(-1)
        }
        
        binding.btnNextMonth.setOnClickListener {
            cambiarMes(1)
        }
    }
    
    private fun observarViewModel() {
        eventViewModel.eventos.observe(viewLifecycleOwner) { eventos ->
            adaptadorEventos.updateEventos(eventos)
            
            if (fechaSeleccionada != null) {
                binding.tvScheduleHeader.visibility = View.VISIBLE
                binding.tvScheduleHeader.text = fechaSeleccionada!!.format(formateadorEncabezado).uppercase()
            } else {
                binding.tvScheduleHeader.visibility = View.GONE
            }
        }
        
        eventViewModel.diasConEventos.observe(viewLifecycleOwner) { dias ->
            diasConEventos = dias
            configurarCalendario()
        }
    }
    
    private fun alSeleccionarDia(dia: Int) {
        fechaSeleccionada = LocalDate.of(mesAnioActual.year, mesAnioActual.month, dia)
        
        val listaDias = generarDiasDelMes(mesAnioActual)
        adaptadorCalendario = CalendarAdapter(
            days = listaDias,
            currentMonth = mesAnioActual.monthValue,
            selectedDay = dia,
            daysWithEvents = diasConEventos,
            onDayClick = { d -> alSeleccionarDia(d) }
        )
        binding.calendarRecyclerView.adapter = adaptadorCalendario
        
        // Cargar eventos para la fecha seleccionada
        eventViewModel.loadEventosForDate(idUsuario, fechaSeleccionada!!)
    }
    
    private fun irAHoy() {
        mesAnioActual = YearMonth.now()
        fechaSeleccionada = LocalDate.now()
        actualizarVisualizacionMes()
        configurarCalendario()
        eventViewModel.loadEventosForDate(idUsuario, fechaSeleccionada!!)
        eventViewModel.loadDiasConEventos(idUsuario, mesAnioActual.year, mesAnioActual.monthValue)
    }
    
    private fun cambiarMes(desplazamiento: Int) {
        mesAnioActual = mesAnioActual.plusMonths(desplazamiento.toLong())
        fechaSeleccionada = null
        actualizarVisualizacionMes()
        configurarCalendario()
        eventViewModel.clearEventos()
        eventViewModel.loadDiasConEventos(idUsuario, mesAnioActual.year, mesAnioActual.monthValue)
    }
    
    private fun actualizarVisualizacionMes() {
        binding.tvMonthYear.text = mesAnioActual.format(formateadorMes).replaceFirstChar { 
            it.uppercase() 
        }
    }
    
    private fun generarDiasDelMes(mesAnio: YearMonth): List<Int> {
        val listaDias = mutableListOf<Int>()
        
        val primerDiaDelMes = mesAnio.atDay(1).dayOfWeek.value
        
        for (i in 1 until primerDiaDelMes) {
            listaDias.add(0)
        }
        
        for (dia in 1..mesAnio.lengthOfMonth()) {
            listaDias.add(dia)
        }
        
        return listaDias
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
