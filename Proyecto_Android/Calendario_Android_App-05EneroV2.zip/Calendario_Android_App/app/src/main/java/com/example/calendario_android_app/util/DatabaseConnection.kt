package com.example.calendario_android_app.util

import java.sql.Connection
import java.sql.DriverManager

object DatabaseConnection {
    // 10.0.2.2 is the special alias to your host loopback interface (i.e., localhost on your development machine)
    private const val URL = "jdbc:mariadb://10.0.2.2:3306/calendario_app" 
    private const val USER = "root"
    private const val PASSWORD = ""

    fun getConnection(): Connection? {
        return try {
            Class.forName("org.mariadb.jdbc.Driver")
            DriverManager.getConnection(URL, USER, PASSWORD)
        } catch (e: Exception) {
            android.util.Log.e("DatabaseConnection", "Error connecting to DB", e)
            e.printStackTrace()
            null
        }
    }
}