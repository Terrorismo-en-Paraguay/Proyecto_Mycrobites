package com.example.calendario_android_app.dao

import com.example.calendario_android_app.model.Etiqueta

interface EtiquetaDAO {
    suspend fun insertEtiqueta(etiqueta: Etiqueta, idUsuario: Int): Boolean
    suspend fun getEtiquetasByUsuario(idUsuario: Int): List<Etiqueta>
}
