package com.example.calendario_android_app.dao.impl

import com.example.calendario_android_app.dao.EtiquetaDAO
import com.example.calendario_android_app.model.Etiqueta
import com.example.calendario_android_app.util.DatabaseConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Statement

class EtiquetaDAOImpl : EtiquetaDAO {

    override suspend fun insertEtiqueta(etiqueta: Etiqueta, idUsuario: Int): Boolean = withContext(Dispatchers.IO) {
        val connection = DatabaseConnection.getConnection()
        var success = false
        
        try {
            connection?.let { conn ->
                conn.autoCommit = false // Start transaction

                // Create Tables if not exist
                val createEtiquetasTable = """
                    CREATE TABLE IF NOT EXISTS etiquetas (
                        id_etiqueta INT AUTO_INCREMENT PRIMARY KEY,
                        nombre VARCHAR(100) NOT NULL,
                        color VARCHAR(20) NOT NULL
                    )
                """
                val createLinkTable = """
                    CREATE TABLE IF NOT EXISTS etiquetas_usuarios (
                        id_etiqueta INT NOT NULL,
                        id_usuario INT NOT NULL,
                        PRIMARY KEY (id_etiqueta, id_usuario),
                        FOREIGN KEY (id_etiqueta) REFERENCES etiquetas(id_etiqueta) ON DELETE CASCADE,
                        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
                    )
                """
                
                val createStmt = conn.createStatement()
                createStmt.execute(createEtiquetasTable)
                createStmt.execute(createLinkTable)
                createStmt.close()
                
                // Insert Etiqueta
                val sqlEtiqueta = "INSERT INTO etiquetas (nombre, color) VALUES (?, ?)"
                val stmtEtiqueta = conn.prepareStatement(sqlEtiqueta, Statement.RETURN_GENERATED_KEYS)
                stmtEtiqueta.setString(1, etiqueta.nombre)
                stmtEtiqueta.setString(2, etiqueta.color)
                
                val affectedRows = stmtEtiqueta.executeUpdate()
                
                if (affectedRows > 0) {
                    val generatedKeys = stmtEtiqueta.generatedKeys
                    if (generatedKeys.next()) {
                        val idEtiqueta = generatedKeys.getInt(1)
                        
                        // Insert Link
                        val sqlLink = "INSERT INTO etiquetas_usuarios (id_etiqueta, id_usuario) VALUES (?, ?)"
                        val stmtLink = conn.prepareStatement(sqlLink)
                        stmtLink.setInt(1, idEtiqueta)
                        stmtLink.setInt(2, idUsuario)
                        stmtLink.executeUpdate()
                        stmtLink.close()
                        
                        success = true
                    }
                    generatedKeys.close()
                }
                stmtEtiqueta.close()
                
                if (success) {
                    conn.commit()
                } else {
                    conn.rollback()
                }
                conn.autoCommit = true
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        success
    }

    override suspend fun getEtiquetasByUsuario(idUsuario: Int): List<Etiqueta> = withContext(Dispatchers.IO) {
        val etiquetas = mutableListOf<Etiqueta>()
        val connection = DatabaseConnection.getConnection()
        
        try {
            connection?.let { conn ->
                 // Join query
                val sql = """
                    SELECT e.id_etiqueta, e.nombre, e.color 
                    FROM etiquetas e
                    INNER JOIN etiquetas_usuarios eu ON e.id_etiqueta = eu.id_etiqueta
                    WHERE eu.id_usuario = ?
                """
                val statement = conn.prepareStatement(sql)
                statement.setInt(1, idUsuario)
                
                val resultSet = statement.executeQuery()
                
                while (resultSet.next()) {
                    etiquetas.add(
                        Etiqueta(
                            idEtiqueta = resultSet.getInt("id_etiqueta"),
                            nombre = resultSet.getString("nombre"),
                            color = resultSet.getString("color")
                        )
                    )
                }
                
                resultSet.close()
                statement.close()
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        etiquetas
    }
}
