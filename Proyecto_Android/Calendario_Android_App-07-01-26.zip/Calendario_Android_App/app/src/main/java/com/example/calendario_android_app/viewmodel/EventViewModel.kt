package com.example.calendario_android_app.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.calendario_android_app.dao.impl.EventoDAOImpl
import com.example.calendario_android_app.dao.impl.FestivoDAOImpl
import com.example.calendario_android_app.model.Evento
import com.example.calendario_android_app.model.EstadoEvento
import com.example.calendario_android_app.model.Festivo
import com.example.calendario_android_app.model.Etiqueta
import com.example.calendario_android_app.dao.impl.EtiquetaDAOImpl
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

class EventViewModel : ViewModel() {
    
    private val eventoDAO = EventoDAOImpl()
    private val festivoDAO = FestivoDAOImpl()
    private val etiquetaDAO = EtiquetaDAOImpl()
    
    private val _eventos = MutableLiveData<List<Evento>>()
    val eventos: LiveData<List<Evento>> = _eventos
    
    private val _diasConEventos = MutableLiveData<List<Int>>()
    val diasConEventos: LiveData<List<Int>> = _diasConEventos
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _etiquetas = MutableLiveData<List<Etiqueta>>()
    val etiquetas: LiveData<List<Etiqueta>> = _etiquetas
    
    fun loadEventosForDate(idUsuario: Int, fecha: LocalDate) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Load user events
                val eventosList = eventoDAO.getEventosByUsuarioAndFecha(idUsuario, fecha).toMutableList()
                
                // Load holiday for this date (month/day, year-independent)
                val festivo = festivoDAO.getFestivoByMesYDia(fecha.monthValue, fecha.dayOfMonth)
                festivo?.let {
                    // Convert festivo to evento
                    val festivoEvento = Evento(
                        idEvento = 0,
                        idCreador = null,
                        titulo = it.nombre,
                        descripcion = it.descripcion,
                        fechaInicio = fecha.atStartOfDay(),
                        fechaFin = fecha.atTime(23, 59),
                        ubicacion = "España",
                        estado = EstadoEvento.PENDIENTE
                    )
                    // Add at the beginning
                    eventosList.add(0, festivoEvento)
                }
                
                _eventos.value = eventosList
            } catch (e: Exception) {
                e.printStackTrace()
                _eventos.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadEventosForRange(idUsuario: Int, start: LocalDate, end: LocalDate) {
         viewModelScope.launch {
            _isLoading.value = true
            try {
                // Load user events for range
                val eventosList = eventoDAO.getEventosByUsuarioAndRango(idUsuario, start, end).toMutableList()
                
                // Load holidays. Iterate through each day in range to check for holidays.
                // Optimization: fetch distinct months involved? For just 7 days, iteration is fine.
                var currentDate = start
                while (!currentDate.isAfter(end)) {
                    val festivo = festivoDAO.getFestivoByMesYDia(currentDate.monthValue, currentDate.dayOfMonth)
                    festivo?.let {
                        val festivoEvento = Evento(
                            idEvento = -1 * currentDate.dayOfYear, // Pseudo ID
                            idCreador = null,
                            titulo = it.nombre,
                            descripcion = it.descripcion,
                            fechaInicio = currentDate.atStartOfDay(),
                            fechaFin = currentDate.atTime(23, 59),
                            ubicacion = "España",
                            estado = EstadoEvento.PENDIENTE
                        )
                        eventosList.add(festivoEvento)
                    }
                    currentDate = currentDate.plusDays(1)
                }
                
                _eventos.value = eventosList
            } catch (e: Exception) {
                e.printStackTrace()
                _eventos.value = emptyList() // Or keep previous?
            } finally {
                _isLoading.value = false
            }
         }
    }
    
    fun loadDiasConEventos(idUsuario: Int, year: Int, month: Int) {
        viewModelScope.launch {
            try {
                // Load days with user events
                val diasEventos = eventoDAO.getDiasConEventos(idUsuario, year, month).toMutableSet()
                
                // Load days with holidays (year-independent)
                val diasFestivos = festivoDAO.getDiasFestivos(month)
                diasEventos.addAll(diasFestivos)
                
                _diasConEventos.value = diasEventos.sorted()
            } catch (e: Exception) {
                e.printStackTrace()
                _diasConEventos.value = emptyList()
            }
        }
    }
    
    fun createEvent(evento: Evento, invitados: List<String> = emptyList(), idUsuario: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Hardcode id_creador to idUsuario if null
                val eventoToSave = if (evento.idCreador == null) evento.copy(idCreador = idUsuario) else evento
                
                // Pass idUsuario for link table
                val idEvento = eventoDAO.insertEventoReturnId(eventoToSave, idUsuario)
                if (idEvento != -1) {
                    if (invitados.isNotEmpty()) {
                        eventoDAO.insertInvitados(idEvento, invitados)
                    }
                    // Start date is usually what we care about to refresh
                    loadEventosForDate(idUsuario, evento.fechaInicio.toLocalDate())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun clearEventos() {
        _eventos.value = emptyList()
    }

    fun loadEtiquetas(idUsuario: Int) {
        viewModelScope.launch {
            try {
                _etiquetas.value = etiquetaDAO.getEtiquetasByUsuario(idUsuario)
            } catch (e: Exception) {
                e.printStackTrace()
                _etiquetas.value = emptyList()
            }
        }
    }

    fun createEtiqueta(etiqueta: Etiqueta, idUsuario: Int) {
        viewModelScope.launch {
            try {
                val success = etiquetaDAO.insertEtiqueta(etiqueta, idUsuario)
                if (success) {
                   loadEtiquetas(idUsuario)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
