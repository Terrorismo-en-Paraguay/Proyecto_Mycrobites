package com.example.calendario_android_app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.fragment.NavHostFragment
import com.example.calendario_android_app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    
    // Binding for activity including the drawer
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupDrawerLogic()
    }
    
    private fun setupDrawerLogic() {
        val drawerLayout = binding.drawerLayout
        // Drawer Listener for dynamic updates
        drawerLayout.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
            override fun onDrawerOpened(drawerView: View) {
                updateDrawerHeader()
            }
        })
        
        // Initial populate
        updateDrawerHeader()

        // Handle Collapsible Sections
        setupCollapsibleSection(R.id.section_calendars_header, R.id.container_calendars_list, R.id.iv_expand_calendars)
        setupCollapsibleSection(R.id.section_labels_header, R.id.container_labels_list, R.id.iv_expand_labels)

        // Footer Actions
        findViewById<View>(R.id.btn_settings)?.setOnClickListener {
            Toast.makeText(this, "Configuración: Próximamente", Toast.LENGTH_SHORT).show()
            drawerLayout.closeDrawer(GravityCompat.START)
        }

        findViewById<View>(R.id.btn_help)?.setOnClickListener {
             Toast.makeText(this, "Ayuda: Próximamente", Toast.LENGTH_SHORT).show()
             drawerLayout.closeDrawer(GravityCompat.START)
        }

        findViewById<View>(R.id.btn_logout)?.setOnClickListener {
            // Logout Logic
            com.example.calendario_android_app.utils.SessionManager.clearSession()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()
            drawerLayout.closeDrawer(GravityCompat.START)
            
            // Navigate to Login
            val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as? NavHostFragment
            navHostFragment?.navController?.navigate(R.id.loginFragment) 
                ?: run {
                      // Fallback
                      val navController = androidx.navigation.Navigation.findNavController(this, R.id.nav_host_fragment)
                      navController.navigate(R.id.loginFragment)
                }
        }
    }
    
    private fun setupCollapsibleSection(headerId: Int, contentId: Int, iconId: Int) {
        val header = findViewById<View>(headerId)
        val content = findViewById<View>(contentId)
        val icon = findViewById<ImageView>(iconId)

        header?.setOnClickListener {
            if (content?.visibility == View.VISIBLE) {
                content.visibility = View.GONE
                icon?.setImageResource(R.drawable.ic_arrow_drop_down) // Or rotate
            } else {
                content?.visibility = View.VISIBLE
                icon?.setImageResource(R.drawable.ic_expand_less)
            }
        }
    }
    
    // Public method to allow fragments to open drawer
    fun openDrawer() {
        binding.drawerLayout.openDrawer(GravityCompat.START)
    }

    private fun updateDrawerHeader() {
        val user = com.example.calendario_android_app.utils.SessionManager.currentUser
        val userName = com.example.calendario_android_app.utils.SessionManager.currentClientName ?: "Usuario"
        val userEmail = user?.correo ?: "usuario@email.com"
        val initial = userName.firstOrNull()?.toString()?.uppercase() ?: "U"

        findViewById<TextView>(R.id.tv_user_name)?.text = userName
        findViewById<TextView>(R.id.tv_user_email)?.text = userEmail
        findViewById<TextView>(R.id.tv_avatar_initial)?.text = initial
        
        user?.let {
            // Load labels and groups for this user
            val viewModel = androidx.lifecycle.ViewModelProvider(this)[com.example.calendario_android_app.viewmodel.EventViewModel::class.java]
            val userId = it.id_usuario // Assuming 1 is not hardcoded anymore or fallback
            viewModel.loadEtiquetas(userId)
            viewModel.loadGrupos(userId)
            
            // Observe Groups (Calendars)
            viewModel.grupos.observe(this) { grupos ->
                 val containerCalendars = findViewById<LinearLayout>(R.id.container_calendars_list)
                 containerCalendars?.removeAllViews()
                 
                 for (grupo in grupos) {
                     val checkBox = android.widget.CheckBox(this)
                     checkBox.layoutParams = android.widget.LinearLayout.LayoutParams(
                         android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                         android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 40f, resources.displayMetrics).toInt()
                     )
                     checkBox.text = grupo.nombre
                     checkBox.setTextColor(android.graphics.Color.WHITE)
                     
                     // Custom Tick (Black/White or Theme)
                     checkBox.buttonDrawable = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.selector_checkbox_tick)
                     checkBox.buttonTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
                     
                     checkBox.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
                     checkBox.setPadding(
                         android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt(), 0, 0, 0
                     )
                     
                     checkBox.isChecked = viewModel.isGroupVisible(grupo.idGrupo)
                     
                     checkBox.setOnCheckedChangeListener { _, isChecked ->
                         viewModel.toggleGroupVisibility(grupo.idGrupo, isChecked)
                     }
                     
                     containerCalendars?.addView(checkBox)
                 }
            }
            
            // Observe Labels
            viewModel.etiquetas.observe(this) { etiquetas ->
                 val containerLabels = findViewById<LinearLayout>(R.id.container_labels_list)
                 containerLabels?.removeAllViews()
                 
                 for (etiqueta in etiquetas) {
                     val checkBox = android.widget.CheckBox(this)
                     checkBox.layoutParams = android.widget.LinearLayout.LayoutParams(
                         android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                         android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 40f, resources.displayMetrics).toInt()
                     )
                     checkBox.text = etiqueta.nombre
                     checkBox.setTextColor(android.graphics.Color.WHITE)
                     val color = android.graphics.Color.parseColor(etiqueta.color)
                     
                     val drawable = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.selector_checkbox_tick)?.mutate()
                     checkBox.buttonDrawable = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.selector_checkbox_tick)
                     checkBox.buttonTintList = android.content.res.ColorStateList.valueOf(color)
                     
                     checkBox.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
                     checkBox.setPadding(
                         android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt(), 0, 0, 0
                     )
                     
                     // Sync state
                     val isVisible = viewModel.isLabelVisible(etiqueta.idEtiqueta)
                     checkBox.isChecked = isVisible
                     // If hidden by parent group, disable? Or just uncheck?
                     // Prompt says "automatically desactivate checkout", so uncheck. 
                     // Can also disable to show dependency:
                     // checkBox.isEnabled = viewModel.isGroupVisible(personalGroupId?) -- complexity: need to know parent.
                     // For now just uncheck.

                     // Listener
                     checkBox.setOnCheckedChangeListener { _, isChecked ->
                         viewModel.toggleLabelVisibility(etiqueta.idEtiqueta, isChecked)
                     }
                     
                     containerLabels?.addView(checkBox)
                 }
            }
        }
    }
}