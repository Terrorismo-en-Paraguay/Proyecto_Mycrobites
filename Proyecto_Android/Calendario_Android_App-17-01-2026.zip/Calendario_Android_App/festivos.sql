-- SQL Script para crear tabla de festivos (independiente del año)

CREATE TABLE IF NOT EXISTS festivos (
  id_festivo INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  mes INT NOT NULL COMMENT 'Mes del festivo (1-12)',
  dia INT NOT NULL COMMENT 'Día del festivo (1-31)',
  tipo ENUM('nacional', 'religioso', 'regional') DEFAULT 'nacional',
  descripcion TEXT,
  es_fijo BOOLEAN DEFAULT TRUE COMMENT 'TRUE si es fecha fija, FALSE si es móvil (ej: Semana Santa)',
  KEY idx_festivos_mes_dia (mes, dia)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Festivos FIJOS (se repiten cada año en la misma fecha)
INSERT INTO festivos (nombre, mes, dia, tipo, descripcion, es_fijo) VALUES
-- Enero
('Año Nuevo', 1, 1, 'nacional', 'Año Nuevo', TRUE),
('Epifanía del Señor', 1, 6, 'religioso', 'Día de Reyes', TRUE),

-- Marzo
('San José', 3, 19, 'regional', 'San José (Comunidad Valenciana, Murcia, etc.)', TRUE),

-- Mayo
('Día del Trabajador', 5, 1, 'nacional', 'Fiesta del Trabajo', TRUE),

-- Junio
('San Juan', 6, 24, 'religioso', 'Natividad de San Juan Bautista', TRUE),

-- Julio
('Santiago Apóstol', 7, 25, 'religioso', 'Santiago Apóstol, Patrón de España', TRUE),

-- Agosto
('Asunción de la Virgen', 8, 15, 'religioso', 'Asunción de la Virgen', TRUE),

-- Octubre
('Fiesta Nacional de España', 10, 12, 'nacional', 'Día de la Hispanidad', TRUE),

-- Noviembre
('Todos los Santos', 11, 1, 'religioso', 'Día de Todos los Santos', TRUE),

-- Diciembre
('Día de la Constitución', 12, 6, 'nacional', 'Día de la Constitución Española', TRUE),
('Inmaculada Concepción', 12, 8, 'religioso', 'Inmaculada Concepción', TRUE),
('Navidad', 12, 25, 'religioso', 'Navidad', TRUE),
('San Esteban', 12, 26, 'regional', 'San Esteban (Cataluña, Baleares)', TRUE);

-- NOTA: Festivos móviles como Semana Santa y Lunes de Pascua requieren cálculo especial
-- Por ahora se marcan como no fijos y necesitarían una tabla separada o cálculo en código
-- Para 2024-2026 (ejemplo):
INSERT INTO festivos (nombre, mes, dia, tipo, descripcion, es_fijo) VALUES
-- Semana Santa 2024
('Jueves Santo 2024', 3, 28, 'religioso', 'Jueves Santo', FALSE),
('Viernes Santo 2024', 3, 29, 'religioso', 'Viernes Santo', FALSE),
('Lunes de Pascua 2024', 4, 1, 'regional', 'Lunes de Pascua (Cataluña, Valencia, Baleares, etc.)', FALSE),

-- Semana Santa 2025
('Jueves Santo 2025', 4, 17, 'religioso', 'Jueves Santo', FALSE),
('Viernes Santo 2025', 4, 18, 'religioso', 'Viernes Santo', FALSE),
('Lunes de Pascua 2025', 4, 21, 'regional', 'Lunes de Pascua (Cataluña, Valencia, Baleares, etc.)', FALSE),

-- Semana Santa 2026
('Jueves Santo 2026', 4, 2, 'religioso', 'Jueves Santo', FALSE),
('Viernes Santo 2026', 4, 3, 'religioso', 'Viernes Santo', FALSE),
('Lunes de Pascua 2026', 4, 6, 'regional', 'Lunes de Pascua (Cataluña, Valencia, Baleares, etc.)', FALSE);
