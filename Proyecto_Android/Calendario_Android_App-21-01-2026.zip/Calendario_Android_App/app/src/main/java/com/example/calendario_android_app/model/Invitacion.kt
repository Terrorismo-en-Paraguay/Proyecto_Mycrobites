package com.example.calendario_android_app.model

data class Invitacion(
    val id: Int = 0,
    val idEvento: Int,
    val email: String
)
