package com.example.calendario_android_app.dao.impl

import com.example.calendario_android_app.dao.EventoDAO
import com.example.calendario_android_app.model.Evento
import com.example.calendario_android_app.model.EstadoEvento
import com.example.calendario_android_app.util.DatabaseConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.ResultSet
import java.time.LocalDate
import java.time.LocalDateTime

class EventoDAOImpl : EventoDAO {

    override suspend fun getEventosByUsuarioAndFecha(idUsuario: Int, fecha: LocalDate): List<Evento> = withContext(Dispatchers.IO) {
        val eventos = mutableListOf<Evento>()
        val connection = DatabaseConnection.getConnection()
        
        try {
            connection?.let { conn ->
                val sql = """
                    SELECT e.* 
                    FROM eventos e
                    INNER JOIN eventos_usuarios eu ON e.id_evento = eu.id_evento
                    WHERE eu.id_usuario = ? 
                    AND DATE(e.fecha_inicio) = ?
                    ORDER BY e.fecha_inicio ASC
                """
                
                val statement = conn.prepareStatement(sql)
                statement.setInt(1, idUsuario)
                statement.setString(2, fecha.toString())
                
                val resultSet = statement.executeQuery()
                
                while (resultSet.next()) {
                    eventos.add(mapResultSetToEvento(resultSet))
                }
                
                resultSet.close()
                statement.close()
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        eventos
    }

    override suspend fun getEventosByUsuario(idUsuario: Int): List<Evento> = withContext(Dispatchers.IO) {
        val eventos = mutableListOf<Evento>()
        val connection = DatabaseConnection.getConnection()
        
        try {
            connection?.let { conn ->
                val sql = """
                    SELECT e.* 
                    FROM eventos e
                    INNER JOIN eventos_usuarios eu ON e.id_evento = eu.id_evento
                    WHERE eu.id_usuario = ?
                    ORDER BY e.fecha_inicio ASC
                """
                
                val statement = conn.prepareStatement(sql)
                statement.setInt(1, idUsuario)
                
                val resultSet = statement.executeQuery()
                
                while (resultSet.next()) {
                    eventos.add(mapResultSetToEvento(resultSet))
                }
                
                resultSet.close()
                statement.close()
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        eventos
    }

    override suspend fun insertEvento(evento: Evento): Boolean = withContext(Dispatchers.IO) {
        val connection = DatabaseConnection.getConnection()
        var success = false
        
        try {
            connection?.let { conn ->
                val sql = """
                    INSERT INTO eventos (id_creador, titulo, descripcion, fecha_inicio, fecha_fin, ubicacion, estado)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """
                
                val statement = conn.prepareStatement(sql)
                statement.setObject(1, evento.idCreador)
                statement.setString(2, evento.titulo)
                statement.setString(3, evento.descripcion)
                statement.setObject(4, evento.fechaInicio)
                statement.setObject(5, evento.fechaFin)
                statement.setString(6, evento.ubicacion)
                statement.setString(7, evento.estado.valor)
                
                success = statement.executeUpdate() > 0
                statement.close()
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        success
    }

    override suspend fun getDiasConEventos(idUsuario: Int, year: Int, month: Int): List<Int> = withContext(Dispatchers.IO) {
        val dias = mutableListOf<Int>()
        val connection = DatabaseConnection.getConnection()
        
        try {
            connection?.let { conn ->
                val sql = """
                    SELECT DISTINCT DAY(e.fecha_inicio) as dia
                    FROM eventos e
                    INNER JOIN eventos_usuarios eu ON e.id_evento = eu.id_evento
                    WHERE eu.id_usuario = ?
                    AND YEAR(e.fecha_inicio) = ?
                    AND MONTH(e.fecha_inicio) = ?
                    ORDER BY dia ASC
                """
                
                val statement = conn.prepareStatement(sql)
                statement.setInt(1, idUsuario)
                statement.setInt(2, year)
                statement.setInt(3, month)
                
                val resultSet = statement.executeQuery()
                
                while (resultSet.next()) {
                    dias.add(resultSet.getInt("dia"))
                }
                
                resultSet.close()
                statement.close()
                conn.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        dias
    }

    private fun mapResultSetToEvento(rs: ResultSet): Evento {
        return Evento(
            idEvento = rs.getInt("id_evento"),
            idCreador = rs.getObject("id_creador") as? Int,
            titulo = rs.getString("titulo"),
            descripcion = rs.getString("descripcion"),
            fechaInicio = rs.getTimestamp("fecha_inicio").toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDateTime(),
            fechaFin = rs.getTimestamp("fecha_fin").toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDateTime(),
            ubicacion = rs.getString("ubicacion"),
            estado = EstadoEvento.fromString(rs.getString("estado")),
            creadoEl = rs.getTimestamp("creado_el")?.toInstant()
                ?.atZone(java.time.ZoneId.systemDefault())
                ?.toLocalDateTime(),
            actualizadoEl = rs.getTimestamp("actualizado_el")?.toInstant()
                ?.atZone(java.time.ZoneId.systemDefault())
                ?.toLocalDateTime()
        )
    }
}
