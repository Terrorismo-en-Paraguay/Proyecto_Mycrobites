package com.example.calendario_android_app.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.calendario_android_app.dao.impl.EventoDAOImpl
import com.example.calendario_android_app.dao.impl.FestivoDAOImpl
import com.example.calendario_android_app.model.Evento
import com.example.calendario_android_app.model.EstadoEvento
import com.example.calendario_android_app.model.Festivo
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

class EventViewModel : ViewModel() {
    
    private val eventoDAO = EventoDAOImpl()
    private val festivoDAO = FestivoDAOImpl()
    
    private val _eventos = MutableLiveData<List<Evento>>()
    val eventos: LiveData<List<Evento>> = _eventos
    
    private val _diasConEventos = MutableLiveData<List<Int>>()
    val diasConEventos: LiveData<List<Int>> = _diasConEventos
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    fun loadEventosForDate(idUsuario: Int, fecha: LocalDate) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Load user events
                val eventosList = eventoDAO.getEventosByUsuarioAndFecha(idUsuario, fecha).toMutableList()
                
                // Load holiday for this date (month/day, year-independent)
                val festivo = festivoDAO.getFestivoByMesYDia(fecha.monthValue, fecha.dayOfMonth)
                festivo?.let {
                    // Convert festivo to evento
                    val festivoEvento = Evento(
                        idEvento = 0,
                        idCreador = null,
                        titulo = it.nombre,
                        descripcion = it.descripcion,
                        fechaInicio = fecha.atStartOfDay(),
                        fechaFin = fecha.atTime(23, 59),
                        ubicacion = "España",
                        estado = EstadoEvento.PENDIENTE
                    )
                    // Add at the beginning
                    eventosList.add(0, festivoEvento)
                }
                
                _eventos.value = eventosList
            } catch (e: Exception) {
                e.printStackTrace()
                _eventos.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun loadDiasConEventos(idUsuario: Int, year: Int, month: Int) {
        viewModelScope.launch {
            try {
                // Load days with user events
                val diasEventos = eventoDAO.getDiasConEventos(idUsuario, year, month).toMutableSet()
                
                // Load days with holidays (year-independent)
                val diasFestivos = festivoDAO.getDiasFestivos(month)
                diasEventos.addAll(diasFestivos)
                
                _diasConEventos.value = diasEventos.sorted()
            } catch (e: Exception) {
                e.printStackTrace()
                _diasConEventos.value = emptyList()
            }
        }
    }
    
    fun clearEventos() {
        _eventos.value = emptyList()
    }
}
