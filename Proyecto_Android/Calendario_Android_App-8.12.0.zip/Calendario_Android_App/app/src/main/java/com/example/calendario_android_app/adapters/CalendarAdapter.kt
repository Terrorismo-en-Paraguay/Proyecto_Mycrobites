package com.example.calendario_android_app.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.calendario_android_app.R

class CalendarAdapter(
    private val days: List<Int>, // 0 for empty, 1-31 for days
    private val currentMonth: Int,
    private val selectedDay: Int,
    private val daysWithEvents: List<Int> = emptyList(), // Days that have events
    private val onDayClick: (Int) -> Unit
) : RecyclerView.Adapter<CalendarAdapter.DayViewHolder>() {

    class DayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDay: TextView = view.findViewById(R.id.tv_day_number)
        val viewDot: View = view.findViewById(R.id.view_event_dot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_calendar_day, parent, false)
        return DayViewHolder(view)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        val day = days[position]
        
        if (day == 0) {
            holder.tvDay.text = ""
            holder.viewDot.visibility = View.GONE
            holder.itemView.setOnClickListener(null)
            holder.tvDay.background = null
        } else {
            holder.tvDay.text = day.toString()
            holder.itemView.setOnClickListener { onDayClick(day) }

            // Highlighting logic
            if (day == selectedDay) {
                holder.tvDay.setTextColor(Color.WHITE)
                holder.tvDay.setBackgroundResource(R.drawable.bg_circle_selected)
            } else {
                 holder.tvDay.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_secondary))
                 holder.tvDay.background = null
            }

            // Show dot if this day has events
            if (daysWithEvents.contains(day)) {
                 holder.viewDot.visibility = View.VISIBLE
                 // Use primary purple color for event dots
                 holder.viewDot.backgroundTintList = ContextCompat.getColorStateList(
                     holder.itemView.context, 
                     R.color.primary_200
                 )
            } else {
                holder.viewDot.visibility = View.GONE
            }
        }
    }

    override fun getItemCount() = days.size
}
