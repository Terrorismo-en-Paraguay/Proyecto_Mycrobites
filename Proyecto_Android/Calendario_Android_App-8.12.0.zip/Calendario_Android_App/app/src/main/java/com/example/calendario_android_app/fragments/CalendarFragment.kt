package com.example.calendario_android_app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.calendario_android_app.databinding.FragmentCalendarBinding
import com.example.calendario_android_app.adapters.CalendarAdapter
import com.example.calendario_android_app.adapters.EventAdapter
import com.example.calendario_android_app.model.Evento
import com.example.calendario_android_app.viewmodel.EventViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class CalendarFragment : Fragment() {

    private var _binding: FragmentCalendarBinding? = null
    private val binding get() = _binding!!
    
    private val eventViewModel: EventViewModel by viewModels()
    private lateinit var eventAdapter: EventAdapter
    private lateinit var calendarAdapter: CalendarAdapter
    
    private var currentYearMonth = YearMonth.now()
    private var selectedDate: LocalDate? = null
    private var userId: Int = 1 // TODO: Get from session/login
    private var daysWithEvents: List<Int> = emptyList()
    
    private val monthFormatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale("es", "ES"))
    private val headerFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("es", "ES"))

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupCalendar()
        setupEvents()
        setupListeners()
        observeViewModel()
        
        // Load days with events for current month
        eventViewModel.loadDiasConEventos(userId, currentYearMonth.year, currentYearMonth.monthValue)
    }

    private fun setupCalendar() {
        updateMonthDisplay()
        
        val daysList = generateDaysForMonth(currentYearMonth)
        
        calendarAdapter = CalendarAdapter(
            days = daysList,
            currentMonth = currentYearMonth.monthValue,
            selectedDay = selectedDate?.dayOfMonth ?: -1,
            daysWithEvents = daysWithEvents,
            onDayClick = { day ->
                onDaySelected(day)
            }
        )
        
        binding.calendarRecyclerView.layoutManager = GridLayoutManager(context, 7)
        binding.calendarRecyclerView.adapter = calendarAdapter
    }

    private fun setupEvents() {
        // Initialize with empty list
        eventAdapter = EventAdapter(emptyList())
        binding.eventsRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.eventsRecyclerView.adapter = eventAdapter
        
        // Hide schedule header initially
        binding.tvScheduleHeader.visibility = View.GONE
    }

    private fun setupListeners() {
        binding.fabCreateEvent.setOnClickListener {
            Toast.makeText(context, "Crear Evento Clicked", Toast.LENGTH_SHORT).show()
        }
        
        binding.btnToday.setOnClickListener {
            goToToday()
        }
        
        binding.btnPrevMonth.setOnClickListener {
            changeMonth(-1)
        }
        
        binding.btnNextMonth.setOnClickListener {
            changeMonth(1)
        }
    }
    
    private fun observeViewModel() {
        eventViewModel.eventos.observe(viewLifecycleOwner) { eventos ->
            eventAdapter.updateEventos(eventos)
            
            // Show/hide schedule header based on whether a day is selected
            if (selectedDate != null) {
                binding.tvScheduleHeader.visibility = View.VISIBLE
                binding.tvScheduleHeader.text = selectedDate!!.format(headerFormatter).uppercase()
            } else {
                binding.tvScheduleHeader.visibility = View.GONE
            }
        }
        
        eventViewModel.diasConEventos.observe(viewLifecycleOwner) { dias ->
            // Update days with events and refresh calendar
            daysWithEvents = dias
            setupCalendar()
        }
    }
    
    private fun onDaySelected(day: Int) {
        selectedDate = LocalDate.of(currentYearMonth.year, currentYearMonth.month, day)
        
        // Update calendar to show selection
        val daysList = generateDaysForMonth(currentYearMonth)
        calendarAdapter = CalendarAdapter(
            days = daysList,
            currentMonth = currentYearMonth.monthValue,
            selectedDay = day,
            daysWithEvents = daysWithEvents,
            onDayClick = { d -> onDaySelected(d) }
        )
        binding.calendarRecyclerView.adapter = calendarAdapter
        
        // Load events for selected date
        eventViewModel.loadEventosForDate(userId, selectedDate!!)
    }
    
    private fun goToToday() {
        currentYearMonth = YearMonth.now()
        selectedDate = LocalDate.now()
        updateMonthDisplay()
        setupCalendar()
        eventViewModel.loadEventosForDate(userId, selectedDate!!)
        eventViewModel.loadDiasConEventos(userId, currentYearMonth.year, currentYearMonth.monthValue)
    }
    
    private fun changeMonth(offset: Int) {
        currentYearMonth = currentYearMonth.plusMonths(offset.toLong())
        selectedDate = null
        updateMonthDisplay()
        setupCalendar()
        eventViewModel.clearEventos()
        eventViewModel.loadDiasConEventos(userId, currentYearMonth.year, currentYearMonth.monthValue)
    }
    
    private fun updateMonthDisplay() {
        binding.tvMonthYear.text = currentYearMonth.format(monthFormatter).replaceFirstChar { 
            it.uppercase() 
        }
    }
    
    private fun generateDaysForMonth(yearMonth: YearMonth): List<Int> {
        val daysList = mutableListOf<Int>()
        
        // Get first day of month (1 = Monday, 7 = Sunday)
        val firstDayOfMonth = yearMonth.atDay(1).dayOfWeek.value
        
        // Add empty cells for days before month starts (Monday = 1, so 1 means no empty cells)
        for (i in 1 until firstDayOfMonth) {
            daysList.add(0)
        }
        
        // Add all days of the month
        for (day in 1..yearMonth.lengthOfMonth()) {
            daysList.add(day)
        }
        
        return daysList
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
