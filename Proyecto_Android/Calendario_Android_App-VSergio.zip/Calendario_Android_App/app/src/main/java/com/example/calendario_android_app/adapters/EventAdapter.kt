package com.example.calendario_android_app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.calendario_android_app.R
import com.example.calendario_android_app.model.Evento
import com.example.calendario_android_app.model.EstadoEvento
import java.time.format.DateTimeFormatter

class EventAdapter(private var eventos: List<Evento>) :
    RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    class EventViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTime: TextView = view.findViewById(R.id.tv_event_time)
        val tvTitle: TextView = view.findViewById(R.id.tv_event_title)
        val tvDetails: TextView = view.findViewById(R.id.tv_event_details)
        val cardEvent: CardView = view.findViewById(R.id.card_event)
        val viewIndicator: View = view.findViewById(R.id.view_indicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_calendar_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val evento = eventos[position]
        
        // Format time
        val startTime = evento.fechaInicio.format(timeFormatter)
        holder.tvTime.text = startTime
        
        // Set title
        holder.tvTitle.text = evento.titulo
        
        // Set details (time range + location)
        val endTime = evento.fechaFin.format(timeFormatter)
        val details = buildString {
            append("$startTime - $endTime")
            if (!evento.ubicacion.isNullOrBlank()) {
                append(" • ${evento.ubicacion}")
            }
        }
        holder.tvDetails.text = details
        
        // Set colors based on event status
        val context = holder.itemView.context
        when (evento.estado) {
            EstadoEvento.EN_PROGRESO -> {
                holder.cardEvent.setCardBackgroundColor(
                    ContextCompat.getColor(context, R.color.event_green)
                )
                holder.viewIndicator.setBackgroundColor(
                    ContextCompat.getColor(context, R.color.event_green_text)
                )
                holder.tvTitle.setTextColor(
                    ContextCompat.getColor(context, R.color.event_green_text)
                )
            }
            EstadoEvento.PENDIENTE -> {
                holder.cardEvent.setCardBackgroundColor(
                    ContextCompat.getColor(context, R.color.event_purple)
                )
                holder.viewIndicator.setBackgroundColor(
                    ContextCompat.getColor(context, R.color.event_purple_text)
                )
                holder.tvTitle.setTextColor(
                    ContextCompat.getColor(context, R.color.event_purple_text)
                )
            }
            EstadoEvento.FINALIZADO -> {
                holder.cardEvent.setCardBackgroundColor(
                    ContextCompat.getColor(context, R.color.bg_300)
                )
                holder.viewIndicator.setBackgroundColor(
                    ContextCompat.getColor(context, R.color.text_secondary)
                )
                holder.tvTitle.setTextColor(
                    ContextCompat.getColor(context, R.color.text_secondary)
                )
            }
        }
    }

    override fun getItemCount() = eventos.size
    
    fun updateEventos(newEventos: List<Evento>) {
        eventos = newEventos
        notifyDataSetChanged()
    }
}
