package com.example.calendario_android_app.model

data class Event(
    val title: String,
    val time: String,
    val description: String,
    val colorResId: Int
)
